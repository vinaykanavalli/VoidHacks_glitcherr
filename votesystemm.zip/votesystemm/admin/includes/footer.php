<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2018 <a href="https://www.sourcecodester.com/">SourceCodeSter</a></strong>
</footer>